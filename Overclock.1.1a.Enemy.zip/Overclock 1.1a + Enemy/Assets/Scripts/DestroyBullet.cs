﻿using UnityEngine;
using System.Collections;

public class DestroyBullet : MonoBehaviour {
	
	void Update () {
		transform.Translate (Vector3.right * Time.deltaTime * 230);
		Destroy (gameObject, 1);
	}
}